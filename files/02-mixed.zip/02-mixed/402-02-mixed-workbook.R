

############################################################################################################


# In this workbook -- 02-mixed -- our learning targets are:

# -- Practice how to tidy experimental data for mixed-effects analysis
# -- Begin to develop an understanding of crossed random effects of subjects and stimuli
# -- Practice fitting linear mixed-effects models incorporating random effects of subjects and stimuli


# The aims of the lab session work are:
# -- get practice running the code required to tidy and prepare experimental data for analysis
# -- exercise skills by varying model code -- changing variables, changing options -- so that you can see how the code works
# -- use the opportunity to reflect on and evaluate results -- so that we can support growth in development of 
# understanding of main ideas

# After the lab session, you will see in the answers version of the workbook that you get a further opportunity:
# -- optional -- get practice running the code: so that you can reproduce the figures and results from the lecture and in 
# the book chapter



############################################################################################################


# -- We start by tidying the data -- this is useful for you to learn but it is optional: skip ahead to the analyses
# if you prefer.
# -- We start the analysis bit in Step 4



############################################################################################################
## Step 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to load relevant libraries

library(broom)
library(gridExtra)
library(here)
library(lme4)
library(patchwork)
library(sjPlot)
library(tidyverse)



############################################################################################################
## Step 2: Load data #######################################################################################


# -- Task 2 -- Read in the data files we will be using --  we need to read in:
# CP study word naming rt 180211.dat
# CP study word naming acc 180211.dat
# all.subjects 110614-050316-290518.csv
# "words.items.5 120714 150916.csv

# -- enter and run code here --



############################################################################################################
## Step 3: Tidy data #######################################################################################


# -- Tidying the data involves a number of tasks, some essential and some things we do
# for convenience


# -- Task 3 -- Transform the rt and acc data from wide to long using pivot_longer()

# -- enter and run code here --


## -- inspect

# -- enter and run code here --


# -- Task 4 -- Join data from different sources: 
# -- join RT with accuracy then
# -- join those response data with data about subject attributes
# -- then join those response plus subjects data
# -- with item properties data

# -- enter and run code here --


# -- Task 5 -- Select just the variables we need -- we want:
# item_name, subjectID, RT, accuracy, 
# Lg.UK.CDcount, brookesIMG, AoA_Kup_lem, 
# Ortho_N, regularity, Length, BG_Mean, 
# Voice,	Nasal,	Fricative,	Liquid_SV,	
# Bilabials,	Labiodentals,	Alveolars,	
# Palatals,	Velars,	Glottals, age.months, 
# TOWREW_skill, TOWRENW_skill, spoonerisms, CART_score

# -- enter and run code here --


# -- Q.1. -- Select different variables -- You could analyze the CP study data for a research 
# report. What if you wanted to analyze a different set of variables, 
# could you select different variables?


# -- Task 6 -- Filter the observations

# -- get rid of observations about FALSE

# -- enter and run code here --


# -- get rid of RT less than or equal to 200

# -- enter and run code here --


# -- Q.2. -- Vary the filter conditions in different ways --
# -- Q.2.1. -- Change the threshold for including RTs from RT >= 200 to something else
# -- Q.2.2. -- Can you assess what impact the change has? 
# -- Hint Q.2.2. -- Note that you can count the number of observations (rows) in a dataset
# using e.g. length(data.set.name$variable.name)


# -- Task 7 -- Remove missing (NA) values

# -- enter and run code here --


## inspect

# -- enter and run code here --


# -- Task 8 -- Create a .csv from the tidied data

# -- enter and run code here --



############################################################################################################
## Step 4: Read in pre-tidied data #########################################################################


# -- Task 9 -- Read in .csv of pre-tidied data, if you want to skip the tidying process steps

long.all.noNAs <- read_csv("long.all.noNAs.csv", 
                           col_types = cols(
                             subjectID = col_factor(),
                             item_name = col_factor()
                           )
                          ) 



############################################################################################################
## Step 5: Analyze data with lm ############################################################################


# -- Task 10 -- Visualize the relationship between frequency and RT, ignoring participant differences
# -- hint: Task 10 -- Draw a scatterplot
# -- hint: Task 10 -- Remember in this dataset, word frequency information is in Lg.UK.CDcount

# -- enter and run code here --


# -- Task 11 -- Estimate the relationship between frequency and RT, ignoring participant differences
# -- hint: Task 11 -- Use lm()

# -- enter and run code here --


# -- Q.3. -- Vary the linear model using different outcomes or predictors -- 

# -- Q.3.1. -- What is the estimate of the effect of Length on RT?
# -- Q.3.2. -- What does the estimate tell you about how RT varies in relation to word length?
# -- Q.3.3. -- What is the R-squared for the model?

# -- enter answers here --


# -- Q.3.4. -- Change the predictor from frequency to something else: you choose.

# -- enter and run code here --

# -- Q.3.5. -- Produce a scatterplot to visualize the relationship between the two variables: 
# does the relationship you see in the plot match the coefficient you see in the model estimates?

# -- enter answer here --


# -- Task 12 -- Visualize the relationship between frequency and RT, separately for each participant
# -- hint: Task 12 -- Use facet_wrap()

# -- enter and run code here --


# -- Q.3.6. -- Can you visualize the relationship between RT and Length, also, separately for each participant?

# -- enter and run code here --

# -- Q.3.7. -- What do you conclude from this plot about the Length effect, and about how the effect varies?

# -- enter answer here --



############################################################################################################
## Step 6: Analyze data with lmer ##########################################################################


# -- Task 13 -- Fit a linear mixed-effects model of the association between RT and frequency
# including the random effect of participants on intercepts and on the slope of the frequency effect
# -- hint: Task 13 -- You need to specify:
# -- the lmer() function
# -- RT as the outcome
# -- frequency (Lg.UK.CDcount) as the fixed effects predictor
# -- plus random effects including the effect of participants (subjectID)
# on intercepts (1) and on the slopes of the frequency effect (Lg.UK.CDcount)
# Check the chapter code examples if you need help

# -- enter and run code here --

# -- Q.4. -- What are the differences between the lm() and the lmer() model results?

# -- enter answer here --


# -- Task 14 -- Fit a linear mixed-effects model, including the random effects of participants on intercepts 
# and on the slope of the frequency effect, as well as the random effect of items on intercepts

# -- enter and run code here --



# -- Q.5. -- Can you describe the differences between the models with vs. without the item term?
# -- Q.5.1. -- How do the random effects differ?
# -- Q.5.2. -- How do the fixed effects estimates differ?


# -- Q.6. -- Now fit a mixed-effects model for the effect of Length on RT
# Include the random effects of participants on intercepts and on the slope of the 
# length effect, as well as the random effect of items on intercepts

# -- enter and run code here --

# -- Q.6.1. -- What are the random effects estimates -- variances?
# -- Q.6.2. -- What is the estimate of the effect of length?
# -- Q.6.3. -- What does the estimate tell you about how RT varies as Length varies?



############################################################################################################


