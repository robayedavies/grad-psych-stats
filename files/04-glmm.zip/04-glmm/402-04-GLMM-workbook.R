


############################################################################################################


# The aims of the lab session work are to:
# -- understand the reasons for using Generalized Linear Mixed-effects models (GLMMs) when we 
# analyze discrete outcome variables
# -- recognize the limitations of alternative methods for analyzing such outcomes
# -- practice running GLMMs with varying random effects structures
# -- practice reporting the results of GLMMs, including through the use of model plots

# My recommendations for learning are:
# -- run generalized linear mixed-effects models of demonstration data
# -- run generalized linear mixed-effects models of alternate data sets
# -- play with the .R code used to create examples for the lecture
# -- edit example code to create alternate visualizations



############################################################################################################
## Step 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to load relevant libraries

library(broom)
library(effects)
library(gridExtra)
library(here)
library(lattice)
library(knitr)
library(lme4)
library(MuMIn)
library(sjPlot)
library(tidyverse)



############################################################################################################
## Step 2: Load data #######################################################################################


# -- Task 2 -- Read in the data files we will be using --
# -- The core example dataset for 04-glmm: the Ricketts child word learning study:
# long.orth_2020-08-11.csv

# -- enter and run code here --



############################################################################################################
## Step 3: Tidy data #######################################################################################


# -- We shall need to recode the categorical variables (factors) in  the core 
# example dataset
# long.orth_2020-08-11.csv
# -- Note that I refer to the dataset as: long.orth


# -- Task 3 -- Inspect the data --

# -- enter and run code here --


# -- Q.1.1. -- Look at the summaries for the variables Time, Instructions and 
# Orthography. Assuming that the read_csv() action went as required, you will see 
# how R presents factor summaries by default.
# What do the variable summaries tell you about the factor level coding, and the 
# number of observations in each level?
# -- Hint Q.1.1. -- For a factor like Orthography, the column values code for 
# whether the observations in a data row are associated with the condition absent 
# or the condition present.
# It is simpler to talk about absent or present as being *levels* of Orthography 
# condition.

# You can ask R what the levels of a factor are using:
levels(long.orth$Orthography)

# -- enter answer here --

# -- Q.1.2. -- Are there any surprises in the summary of factors?
# -- Hint Q.1.2. -- We would hope to see equal numbers of observations at 
# different levels for a factor.

# -- enter answer here --


# -- Task 4 -- Fit a Generalized Linear Model --
# -- You can reproduce the example analysis in the chapter with?

# -- enter and run code here --


# -- Q.2.1. -- What is the estimated effect of Instructions on Score?
# -- hint: Q.2.1. -- Fit a glm()  model with Instructions as the predictor

# -- write your code here and run it --

# -- Q.2.2. -- Can you briefly indicate in words what the estimate says about 
# how log odds Score (response correct vs. incorrect) changes in association with 
# different Instructions conditions?

# -- enter answer here --


# -- Task 5 -- Use the memisc library and recode the factors, to use 
# contrast sum (effect) coding --


# -- Loading the memisc library may avoid triggering warnings as seen by some, 
# previously, we will see:
library(memisc)

# -- see information about the potential warnings here:
# https://github.com/melff/memisc/issues/47  
  
  
# -- Now first check then change the factor coding for each factor
# -- Change factor coding to sum (-1, 1) coding for each factor

# -- enter and run code here --


# -- You can check out the manual information here:
# https://rdrr.io/cran/memisc/man/contrasts.html
# https://www.elff.eu/software/memisc/manual/contrasts/  


# -- Q.3.1. -- Experiment: what happens if you change the first number for one of the factors?
# -- Uncomment the following code, and reflect on what you see
# contrasts(long.orth$Time) <- contr.sum(3, base = 1)
# contrasts(long.orth$Time)

# -- enter answer here --

# -- Q.3.2. -- Experiment: what happens if you change the base number for one of the factors?
# -- Uncomment the following code, and reflect on what you see
# contrasts(long.orth$Time) <- contr.sum(2, base = 1)
# contrasts(long.orth$Time)

# -- enter answer here --



############################################################################################################
## Step 3: Analyze the data: random intercepts #############################################################


# -- Task 6 -- We can take a quick look at a random intercepts model --
# -- Specify a model with:
# -- The correct function
# -- Outcome = Score
# -- Predictors = 
#   Time + Orthography + Instructions + zConsistency_H + 
#   Orthography:Instructions +
#   Orthography:zConsistency_H +
# -- Plus random effects:
# -- Random effect of participants (Participant) on intercepts
# -- Random effect of items (Word) on intercepts
# -- Using the "bobyqa" optimizer
  
# -- Run the code to fit the model and get a summary of results, as shown in the chapter

# -- enter and run code here --


# -- Q.4.1. -- Experiment: replace the fixed effects with another variable e.g. mean_z_read (an aggregate 
# measure of reading skill) to get a feel for how the code works.
# -- What is the estimate for the mean_z_read effect?

# -- enter and run code here --

# -- enter answer here --

# -- Q.4.2. -- Can you briefly indicate in words what the estimate says about how log odds Score 
# (response correct vs. incorrect) changes in association with mean_z_read score?

# -- enter and run code here --

# -- enter answer here --


# -- Task 7 -- Visualize the significant effects of the Orthography and Consistency factors --

# First using sjPlot plot_model() function

# -- enter and run code here --

# Second using the effects library effect() function

# -- enter and run code here --


# -- Task 8 -- Pick a different predictor variable to visualize
# -- Hint Task 8 -- Notice that in the preceding code chunks, I assign the plot objects to names
# and then use grid.arrange to present the named plots in grids.
# To produce and show a plot, don't do that, just adapt and use the plot functions.

# -- enter and run code here --


# -- Task 9 -- optional -- Can you figure out how to plot interaction effects?
# -- Hint Task 9 -- Take a look at the documentation referenced in the book chapter
# https://strengejacke.github.io/sjPlot/articles/plot_interactions.html

# -- enter and run code here --



############################################################################################################
## Step 4: Analyze the data: model comparisons #############################################################


# -- Task 10 -- We are now going to fit a series of models and evaluate their relative fit --

# -- Note that the models all have the same fixed effects.
# -- Note also that while we will be comparing models varying in random effects 
# (see 03-mixed materials)
# we are not going to use REML=TRUE
# -- See here for why:
# https://bbolker.github.io/mixedmodels-misc/glmmFAQ.html#reml-for-glmms


# -- First the minimum random intercepts model
# -- Specify a model with:
# -- The correct function
# -- Outcome = Score
# -- Predictors = 
#   Time + Orthography + Instructions + zConsistency_H + 
#   Orthography:Instructions +
#   Orthography:zConsistency_H +
# -- Plus random effects:
# -- Random effect of participants (Participant) on intercepts
# -- Random effect of items (Word) on intercepts
# -- Using the "bobyqa" optimizer

# -- Run the code to fit the model and get a summary of results, as shown in the chapter

# -- enter and run code here --


# -- Second the maximum model: this will take several seconds
# -- Specify a model with:
# -- The correct function
# -- Outcome = Score
# -- Predictors = 
#   Time + Orthography + Instructions + zConsistency_H + 
#   Orthography:Instructions +
#   Orthography:zConsistency_H +
# -- Plus random effects:
# -- Random effect of participants (Participant) on intercepts
# -- Random effect of items (Word) on intercepts
# -- Plus:
# -- Random effects of participants on the slopes of within-participant effects
# -- Random effects of items on the slopes of within-item effects  
# -- Plus:
# -- Allow for covariance between random intercepts and random slopes  

# -- Run the code to fit the model and get a summary of results, as shown in the chapter

# -- enter and run code here -


# -- Then models adding random effects a bit at a time --

# -- Keep the fixed effects the same:
# -- Outcome = Score
# -- Predictors = 
#   Time + Orthography + Instructions + zConsistency_H + 
#   Orthography:Instructions +
#   Orthography:zConsistency_H +

# -- Plus random effects:
# -- Random effect of participants (Participant) on intercepts
# -- Random effect of items (Word) on intercepts


# -- Add one extra random effect at a time


# -- Add orthography:
# -- Add code to include a random effect of participants on the slopes of the
# effect of Orthography
# -- And add code to include a random effect of items on the slopes of the
# effect of Orthography

# -- enter and run code here -


# -- Add Instructions
# -- Add code to include a random effect of items on the slopes of the
# effect of Instructions

# -- enter and run code here -


# -- Add consistency
# -- Add code to include a random effect of participants on the slopes of the
# effect of consistency (zConsistency_H)

# -- enter and run code here -


# -- Add Time
# -- Add code to include a random effect of participants on the slopes of the
# effect of Time
# -- And add code to include a random effect of items on the slopes of the
# effect of Time

# -- enter and run code here -


# -- Q.5.1. -- Which models converge and which models do not converge?

# -- enter answer here --

# -- Q.5.2. -- How can you tell?

# -- enter answer here --


# -- Task 11 -- Now compare the models that do converge: min vs. 2, vs. 3 --
anova(long.orth.min.glmer, long.orth.2.glmer)
anova(long.orth.min.glmer, long.orth.3.glmer)


# -- Task 12 -- Before we move on, check out some of the code adjustments we have used --
  
# -- Q.6.1. -- What does using bobyqa do? Delete glmerControl() and report wha
# t impact does this have?
# -- Run the code to fit the model and get a summary of results, as shown in the chapter

# -- enter and run code here -

# -- Q.6.2. -- What does using dummy() in the random effects coding do?
# -- Experiment: check out models 2 or 3, removing dummy() from the random effects 
# coding to see

# -- enter and run code here --



############################################################################################################
## Step 4: Exercise analyses ###############################################################################


# -- Task 13 -- Now analyze the gavagai adult word learning data --

#-- Read the data in:
# noun-verb-learning-study.csv

# -- enter and run code here --

# -- Create a centered learning block numeric variable

# -- enter and run code here --


# -- Fit a random intercepts model

# -- enter and run code here --


# -- Now, using the study information and a series of model comparisons, can you select
# a model with a comprehensive defensible random effects structure?



############################################################################################################
# Reproduce the plots in the chapter and slides ############################################################


# This plot concerning the gavagai data is enlightening about the limits of using lm to model accuracy
# -- each point shows per-subject accuracy proportion per block
# -- each thin line shows the trend per-subject mis-estimated by lm rather than logit GLM but indicative
# -- the thick lines show the group trend                                                                           
# -- the plot pretty much shows what the original arcsine analysis was doing
# -- we can edit the plot for use

# -- first, we need to calculate the proportion of responses that are correct per person for each block of (24) learning trials

correct <- gavagai %>%
  group_by(Experiment, Subjecta, block) %>%                                 
  # group data by subject ID (Subjecta) and block, to get summary of
  # accuracy for each subject for each block, then
  summarise(sum = sum(accuracy)) %>%
  # calculate accuracy of responses per person per block then
  mutate(proportion = sum/24)

# -- then we do the plot
pcorrect <- ggplot(correct, aes(x = block, y = proportion))
pcorrect + 
  geom_jitter(alpha = .3) + # jitter points, adding random noise to x,y coordinates; use alpha() to modify transparency
  geom_smooth(aes(group = Subjecta), method="lm", se = F, alpha = .65, colour = "darkgrey") + # add a learning model line for each person
  geom_smooth(aes(group = 1), method="lm", se = F, size = 2, colour = "black") + # add a line to show average group learning
  scale_x_continuous(breaks = seq(2,12, by = 2)) + xlab("Block") + # modify scale axis labeling
  scale_y_continuous(breaks = seq(0,1, by = .2)) +  ylab("Proportion correct") + # modify scale axis labeling
  theme_bw() + # use black and white theme
  theme(axis.title.x = element_text(size = 25), axis.title.y = element_text(size = 25), axis.text = element_text(size = 15)) +
  facet_grid(.~Experiment) + # create a separate plot for each experimental condition
  theme(strip.text.x = element_text(size = 20)) + theme(strip.background = element_rect(colour = "grey")) # modify appearance of subplots

