

############################################################################################################


# In this workbook, our learning targets are:

# -- concepts: multilevel data and multilevel modeling
# -- skills: visualization -- examine overall and within-class trends
# -- skills: run linear models over all data -- and within each class
# -- skills: use the lmer() function to fit models of multilevel data


# The aims of the lab session work are:
# -- get practice running the code: so that you can reproduce the figures and results from the lecture and in 
# the book chapter
# -- exercise skills by varying code -- changing variables, changing options -- so that you can see how the code works
# -- use the opportunity to reflect on and evaluate results -- so that we can support growth in development of 
# understanding of main ideas



############################################################################################################
## Step 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to load relevant libraries

library(broom)
library(gridExtra)
library(lme4)
library(tidyverse)



############################################################################################################
## Step 2: Load data #######################################################################################


# -- Task 2 -- Read in the data file we will be using: BAFACALO_DATASET.RData

# -- enter and run code here --


# -- Inspect what you have:

  # -- enter and run code here --



############################################################################################################
## Step 3: Tidy data #######################################################################################


# -- Tidying the data involves a number of tasks, some essential and some things we do
# for convenience


# -- Task 3 -- We start by selecting the variables we want: 
# class_number, participant_id,
# portuguese, english, math, physics
# -- We use the dplyr function select() to pick just the variables needed

# -- enter and run code here --

# -- inspect:

# -- enter and run code here --


# -- Q.1. -- Do you know what you are doing with select()? Can you select a different set of variables?


# -- Task 4 -- Take missing values out of the brazil data

# -- enter and run code here --

# -- inspect:

# -- enter and run code here --


# -- Q.2. -- Do you see the difference between the summary of the brazil data shown before and after you
# run na.omit()? What is it?


# -- Task 5 -- Get R to treat a variable as a type object of the kind required -- using the 
# as.numeric() or as.factor() functions

# -- enter and run code here --


# -- inspect:

# -- enter and run code here --


# -- Q.3. -- Do you see the difference between the summary of the brazil data shown before and after you
# run as.numeric() or as.factor() function lines? What is it?


# -- Task 6 -- Exercise -- experiment with coercion
# 1. Test out variable type using the is...() function for some of the variables
# 2. Test out coercion -- and its results -- using the as...() function for some of the variables
# 3. Look at the results using summary()




############################################################################################################
## Step 4: Visualize relationship ##########################################################################


# -- Task 7 -- Visualize the relationship between portuguese and english grades using a scatterplot

# -- enter and run code here --


# -- Task 8 -- Exercise -- edit plots

# 1. Change the x and y variables to math and physics
# 2. Change the theme from theme_bw() to something different
# 3. Change the appearance of the points, try different colour, shape, size

# -- Hint -- Task 8 -- Use the ggplot reference documentation to help you make choices:
#   https://ggplot2.tidyverse.org/reference/
# -- You should be using webpages like the reference often.



############################################################################################################
## Step 5: Analyze relationship lm #########################################################################


# -- Task 9 -- Analyze the relationship between english and portuguese grades in the brazil data
# -- You should be able to reproduce the results shown in the slides and the book chapter.

# -- enter and run code here --


# -- Task 10 -- Exercise -- adapt the lm() code to do a different analysis
# -- Change the outcome and predictor variables to math and physics

# -- write code and run it here --


# -- Q.4 -- What is the estimated coefficient of the "effect" of math ability (grade) on physics grade?


# -- Q.5. -- Draw a scatterplot showing the relationship between math and physics grades. Does
# the trend you see in the plot reflect the coefficient you see in the linear model summary?


# -- Q.6. -- How does the strength of the math-physics relationship compare with the english-portuguese
# relationship?



############################################################################################################
## Step 6: visualize relationship for each class ###########################################################


# -- Task 11 -- Plot the relationship between english and portuguese grades separately for each class
# using facet_wrap

# -- enter and run code here --


# -- Task 12 -- Exercises to practice your facet_wrap() skills
# 1. Change the x and y variables to math and physics and draw a facetted scatterplot again
# 2. Experiment with showing the differences between classes in a different way: instead of using
# facet_wrap(), in aes() add colour = class_number, and remove colour from geom_point and
# geom_smooth

# -- enter and run code here --


# -- Q.8. -- Evaluate the consistency between classes of the relationship between math and physics
# grades: what do the plots show? how does this compare with what you see of the relationship
# between english and portuguese grades?



############################################################################################################
## Step 7: mixed-effects analysis ##########################################################################


# -- Task 13 -- Run a linear mixed-effects analysis of the relationship between english and portuguese
# grades using lmer()
# You should be able to replicate the results shown in the slides and the book chapter.

# -- enter and run code here --


# -- Task 14 - Exercise mixed-effects model coding
# 1. Vary the random effects part of the model, while keeping this bit the same:
# lmer(english ~ portuguese + ...)
# 1.1. Change the random effect from (portuguese + 1 | class_number) to
# (1 | class_number) -- what you are doing is asking R to ignore the differences in the slope of the effect of Portuguese grades
# 1.2. Change the random effect from (portuguese + 1 | class_number) to
# (portuguese + 0 | class_number): -- what you are doing is asking R to ignore the differences 
# in the intercept


# -- Q.9. -- Compare the results of the different versions of the model. Can you identify where
# the results are different?


# -- Task 15 - Exercise mixed-effects model coding
# Change the outcome (from english) and the predictor (from portuguese) -- this is about changing
# the fixed effect part of the model
# -- Note that you will need to change the random effect part as well.


# -- Q.10. -- What elements of the model summary stand out for you?
# -- It will help to see what you should notice if you compare the math-physics model with the
# first english-portuguese model.



############################################################################################################
## Step 8: Extension #######################################################################################


# In the lecture materials, I display a plot showing the estimated intercept and coefficient for 
# each class, estimated using separate models for different classes.
# -- Some of you may be interested in how I did that, you can run the following code to see.

# -- use the dplyr %>% syntax to run a model for each class separately, collect together the results into a dataframe
brazlm <- brazil %>% group_by(class_number) %>% do(tidy(lm(english ~ portuguese, data=.)))
brazlm$term <- as.factor(brazlm$term)

# -- extract the per-class estimates of the intercepts and the 'portuguese' effect coefficient estimates
brazlmint <- filter(brazlm, term == '(Intercept)')
brazlmport <- filter(brazlm, term == 'portuguese')

# -- plot the estimates
pbrazlmint <- ggplot(brazlmint, aes(x = class_number, y = estimate, ymin = estimate - std.error, ymax = estimate + std.error))
pbrazlmint <- pbrazlmint + geom_point(size = 2) + geom_linerange() + theme_bw() 
pbrazlmint <- pbrazlmint + ggtitle("Intercept") + ylab("Estimated coefficient +/- SE") + xlab("Class")
pbrazlmint <- pbrazlmint + theme(axis.title.y = element_text(size = 10), axis.text.x = element_blank(), panel.grid = element_blank())
# pbrazlmint

pbrazlmport <- ggplot(brazlmport, aes(x = class_number, y = estimate, ymin = estimate - std.error, ymax = estimate + std.error))
pbrazlmport <- pbrazlmport + geom_point(size = 2) + geom_linerange() + theme_bw() 
pbrazlmport <- pbrazlmport + ggtitle("Portuguese effect") + ylab("Estimated coefficient +/- SE") + xlab("Class")
pbrazlmport <- pbrazlmport + theme(axis.title.y = element_text(size = 10), axis.text.x = element_blank(), panel.grid = element_blank())
# pbrazlmport

# -- ask R to make a grid:

grid.arrange(pbrazlmint, pbrazlmport,
             ncol = 2)


# Can you change the code to show the estimates for the relationship between physics and math grades?



############################################################################################################


