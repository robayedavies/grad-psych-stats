
############################################################################################################


# In this workbook -- 03-mixed -- our learning targets are:

# -- get practice running the code: so that you can reproduce the figures and results 
# from the lecture and in the book chapter
# -- exercise skills by varying code -- changing variables, changing options 
# -- so that you can see how the code works
# -- use the opportunity to reflect on and evaluate results -- so that we can 
# support growth in development of understanding of main ideas


# We have reached the stage where our learning targets can be detailed -- here, 
# we are concerned with:

# -- being able to specify a mixed-effects model in lmer() code
# -- being able to identify how the mixed-effects model code varies depending on 
# the kinds of random effects 

# -- being able to identify the elements of the output or results that come from an 
# lmer() mixed-effects analysis
# -- being able to interpret the fixed-effects estimates
# -- being able to interpret the random effects estimates, variance, covariance

# -- being able to describe in words and summary tables the results of a mixed-effects model
# -- being able to visualise the effects estimates from a mixed-effects model



############################################################################################################


# -- In the following steps:
# -- I first show you how to prepare data for analysis, just run the code and 
# do the exercises;
# -- I then walk through a sequence of tasks where I show you how to fit and 
# compare a series of models, again, just run the code and do the exercises;
# -- the critical step is Step 7, where I ask you to follow the examples, running your 
# own series of models but with your selection of variables;
# -- finally, I show you how to reproduce some of the keyplots from the book 
# chapter and slides, for your information


############################################################################################################
## Step 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to load relevant libraries

library(broom)
library(gridExtra)
library(here)
library(lme4)
library(tidyverse)



############################################################################################################
## Step 2: Load data #######################################################################################


# -- Task 2 -- Read in the data file we will be using:
# subjects.behaviour.words-310114.csv

# -- enter and run code here --


# -- And inspect it:

# -- enter and run code here --



############################################################################################################
## Step 3: Tidy data #######################################################################################


# -- We shall be filtering the data and transforming one variable.
# -- We do this work and use data visualization to examine the impacts of the actions.


# -- Task 3 -- Produce a density plot showing word recognition reaction time, 
# for both correct and incorrect responses

# -- enter and run code here --


# -- Task 4 -- You should try out alternative visualisation methods to reveal the patterns in the distribution of
# variables in the ML dataset (or in your own data).

# Take a look at the geoms documented in: 
#   https://ggplot2.tidyverse.org/reference/#section-layer-geoms

# Would a histogram or a frequency polygon provide a more informative view? 
#   https://ggplot2.tidyverse.org/reference/geom_histogram.html

# What about a dotplot? 
#   https://ggplot2.tidyverse.org/reference/geom_dotplot.html


# -- Task 5 -- Filter out incorrect and outlier short RT observations

# -- enter and run code here --


# -- Task 6 -- Check out the impact of filtering on the number of rows in the dataset
# -- hint: Task 6 -- Calculate the number of rows in each different version of the dataset

# -- enter and run code here --


# -- Task 7 -- Produce a density plot showing word recognition reaction time, 
# for correct responses only

# -- enter and run code here --


# -- Task 8 -- Vary the filter conditions in different ways:
  
# 1. Change the threshold for including RTs from RT >= 200 to something else
# 2. Can you assess what impact the change has? 
# Note that you can count the number of observations (rows) in a dataset using e.g. length()
  
  
# -- Task 9 -- Transform RT to log base 10 RT
# -- hint: Task 9 -- Use the log10() function to create a logrt version of the RT variable

# -- enter and run code here --	


# -- Task 10 -- Produce a density plot showing log10 transformed reaction time, correct responses only

# -- enter and run code here --	


# -- Task 11 -- Produce a density plot showing log10 transformed reaction time, correct responses, 
# separately for each participant

# -- enter and run code here --	


# -- Task 12 -- Can you work out how to adapt the plotting code to show a grid of histograms?

# -- enter and run code here --	


# -- Task 13 -- Can you work out how to adapt the code to show a grid of plots indicating the distribution
# of log RT by different items (instead of participants)?

# -- enter and run code here --	



############################################################################################################


# -- In the following, we will analyze log RT for correct responses as the outcome


############################################################################################################
## Step 4: Use lm ##########################################################################################


# -- As we have done before, we can analyze the data to estimate the effect of frequency, at first,
# ignoring the impact of multilevel structure in our data

# -- Task 14 -- Fit a linear model with log10 RT as the outcome and word frequency (LgSUBTLCD)
# as the predictor

# -- enter and run code here --	


# -- Task 14 -- Vary the linear model using different outcomes or predictors

# It would be useful to experiment with the data.
# 1. Change the predictor from frequency to something else
# -- what do you see when you visualize the relationship between outcome and predictor variables 
# using scatterplots?
# 2. Specify linear models with different predictors: do the relationships you see in plots match the 
# coefficients you see in the model estimates?

# -- enter and run code here --	



############################################################################################################
## Step 5: Use lmer ########################################################################################


# -- Task 15 -- Fit a linear mixed-effects model to estimate the effect of frequency on log RT
# while taking into account random effects:
# -- the random effect of participants on intercepts;
# -- and the random effect of participants on the slopes of the frequency (LgSUBTLCD) effect;
# -- as well as the random effect of items on intercepts
# -- You can specify the random effects of participants allowing for covariance between the random
# intercepts and the random slopes

# -- enter and run code here --	



############################################################################################################
## Step 6: Compare models with different random effects ####################################################


# -- Task 16 -- Fit a linear mixed-effects model to estimate the effect of frequency on log RT
# while taking into account random effects:
# -- using REML
# -- with the same fixed effect (of frequency) but with varying random effects


## First, fit a model with just the random effects:
# -- the random effect of participants on intercepts;
# -- as well as the random effect of items on intercepts
# -- give it a distinct name e.g. model.si

# -- enter and run code here --	

## Second fit a model with just the random effect:
# -- the random effect of items on intercepts
# -- give it a distinct name e.g. model.i

# -- enter and run code here --	

## Third fit a model with just the random effect:
# -- the random effect of subjects on intercepts
# -- give it a distinct name e.g. model.s

# -- enter and run code here --	


# -- Task 17 -- Compare the different models using anova()


## Compare the model.si with the model.i

# -- enter and run code here --	


## Compare the model.si with the model.s

# -- enter and run code here --	


# -- Task 18 -- We know what our conclusions will be, as these analyses replicate what the chapter does


# -- Task 19 -- Now examine whether random slopes are required

## Is it justified to add a random effect of participants on the slopes of the
# frequency effect?

# -- First specify the random slopes model

# -- enter and run code here --	


## Then compare the model.si with the model.slopes

# -- enter and run code here --	



############################################################################################################
## Step 6: p-values and significance using lmerTest ########################################################


# -- Task 20 -- Get p-values for model.slopes using lmerTest

# -- enter and run code here --	



############################################################################################################
## Step 7: Now run your own sequence of lmer models ########################################################


# It will be useful for you to examine model comparisons with a different set of models for the same data.

# You could try to run a series of models in which the fixed effects variable is something different, 
# for example, the effect of word Length or the effect of orthographic neighbourhood size Ortho_N.


# I would consider the model comparisons in the sequence shown in the foregoing, one pair of models at a 
# time, to keep it simple.
# When you look at the model comparison, ask: is the difference between the models a piece of complexity 
# (an effect) whose inclusion in the more complex model is justified or warranted by improved model fit 
# to data?



############################################################################################################

